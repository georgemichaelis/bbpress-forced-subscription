<?php
function bbpts_send_topic_subscription_mail( $post_id,$userid ) {
	    $data  			= get_post($post_id);
		$content 		= $data->post_content;
		
			$cpt = 'topic';
			$title = $data->post_title;
			$link = get_the_permalink($post_id);
			$topic_title = bbp_get_topic_title($post_id);

		if( $userid ) {
		
				if ( get_userdata( $userid ) ) {
					// user exists so start notify
					$message = 'Topic Title: ' . $title . "\r\n" .'Topic Link: '. $link . "\r\n\r\n" .'Topic Content: ' . $content;
					$subject = '[Topic Subscription: ' . $topic_title . ']';
					$email = get_userdata( $userid )->user_email;
					wp_mail( $email, $subject, $message );
				}
		}
}
