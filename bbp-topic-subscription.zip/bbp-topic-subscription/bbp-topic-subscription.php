<?php
/**
 * Plugin Name: Topic Subscription
 * Plugin URI: #
 * Description: This plugin managed bbp topic subscription from admin dashboard.
 * Version: 1.0.0
 * Author: sixthsense
 * Author URI: #
 * License: GPL2
 */
 
 // No direct access
if ( !defined( 'ABSPATH' ) ) exit;

if (!is_admin()) {
	//echo 'Cheating ? You need to be admin to view this !';
	return;
} // is_admin

// Check if bbPress is active
	$plugin = 'bbpress/bbpress.php';
	$network_active = false;
	
    if(!defined('BBPTS_PLUGIN_DIR'))
	define('BBPTS_PLUGIN_DIR', dirname(__FILE__));
	
	include(BBPTS_PLUGIN_DIR . '/includes/subscriptions.php');
	include(BBPTS_PLUGIN_DIR . '/includes/subscription-mail.php');